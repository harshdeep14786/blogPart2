import React, { useState } from 'react';
import './Featured.css';

import Maclipstick from '../../assets/maclipstick.jpg';
import Mac2 from '../../assets/mac2.jpg';
import Mac3 from '../../assets/mac3.jpg';
import Mac4 from '../../assets/mac4.jpg';
import Mac5 from '../../assets/mac5.jpg';

const Featured = ({ product }) => {
    const [isAddedToCart, setIsAddedToCart] = useState(false);

    const handleAddToCart = () => {
        setIsAddedToCart(true);
        // Simulate adding to cart action
        setTimeout(() => setIsAddedToCart(false), 2000); // Reset state after 2 seconds
    };

    return (
        <div className='featured'>
            <h1 className='featured-text'>Top Rated</h1>
            <p className='featured-text'>Selected Products by Millions of People</p>
            <div className='container'>
                <img className='span-3 image-grid-row-2' src={product.images[0]} alt='' />
                {product.images.slice(1).map((image, index) => (
                    <img key={index} src={image} alt='' />
                ))}
                <div className='span-3 img-details'>
                    <div className='top'>
                        <h2>{product.name}</h2>
                        <p>{product.sale}</p>
                        <p className='price'>{product.price}</p>
                    </div>
                    <div className='info-grid'>
                        {product.details.map((detail, index) => (
                            <div key={index}>
                                <div className='info'>
                                    <p className='bold'>{detail.label}:</p><p>{detail.value}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                <div className='span-2 right-img-details'>
                    <p>{product.description}</p> <br />
                    <button className='btn' onClick={handleAddToCart}>
                        {isAddedToCart ? 'ADDED TO CART' : 'ADD TO CART'}
                    </button>
                </div>
            </div>
        </div>
    );
}

const product = {
    name: "Maybelline New York Super Stay Matte Ink Spiced Edition, Exhilarator, 5 ml.",
    sale: "Summer Sale",
    price: "$9.98 $199.60 per ml",
    images: [Maclipstick, Mac2, Mac3, Mac4, Mac5],
    details: [
        { label: "Brand", value: "MAYBELLINE" },
        { label: "Colour", value: "Exhilarator" },
        { label: "Item Form", value: "Liquid" },
        { label: "Finish Type", value: "Matte" }
    ],
    description: "Unique arrow applicator for a more precise liquid lipstick application"
};

const App = () => {
    return <Featured product={product} />;
}

export default App;
