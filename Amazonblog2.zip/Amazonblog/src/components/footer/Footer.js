import React from 'react';
import { FaFacebook, FaInstagram, FaTwitter, FaPinterest } from 'react-icons/fa';
import './Footer.css';

const Footer = ({ socialLinks, footerColumns }) => {
    return (
        <div className='footer'>
            <div className='social'>
                {socialLinks.map((link, index) => (
                    <a key={index} href={link.url} target="_blank" rel="noopener noreferrer" className='icon'>
                        {link.icon}
                    </a>
                ))}
            </div>
            <div className='container'>
                {footerColumns.map((column, index) => (
                    <div key={index} className='col'>
                        <h3>{column.title}</h3>
                        <p>{column.description}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

const socialLinks = [
    { icon: <FaFacebook />, url: 'https://www.facebook.com' },
    { icon: <FaInstagram />, url: 'https://www.instagram.com' },
    { icon: <FaTwitter />, url: 'https://www.twitter.com' },
    { icon: <FaPinterest />, url: 'https://www.pinterest.com' },
];

const footerColumns = [
    { title: 'Amazon Music', description: 'Streams millions of Music' },
    { title: 'Amazon Business', description: 'Everything for your business' },
    { title: 'Amazon Drive', description: 'Cloud storage from Amazon' },
    { title: 'Amazon Web Services', description: 'Scalable Cloud Computing Services' },
];

const App = () => {
    return <Footer socialLinks={socialLinks} footerColumns={footerColumns} />;
};

export default App;
