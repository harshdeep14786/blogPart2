import React, { useState } from 'react';
import { AiOutlineSearch } from 'react-icons/ai';
import './Hero.css';

const Hero = ({ heading, searchText, placeholder }) => {
    const [keyword, setKeyword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Searching for:', keyword);
        // Implement the search logic here
    };

    return (
        <div className='hero'>
            <div className='content'>
                <h1>{heading}</h1>
                <p className='search-text'>{searchText}</p>
                <form className='search' onSubmit={handleSubmit}>
                    <div>
                        <input 
                            type='text' 
                            placeholder={placeholder} 
                            value={keyword} 
                            onChange={(e) => setKeyword(e.target.value)} 
                        />
                    </div>
                    <button type='submit'>
                        <AiOutlineSearch className='icon' />
                    </button>
                </form>
            </div>
        </div>
    );
};

const App = () => {
    return (
        <Hero 
            heading="What are you looking for" 
            searchText="Search for the things you want." 
            placeholder="Enter Keyword.." 
        />
    );
};

export default App;
