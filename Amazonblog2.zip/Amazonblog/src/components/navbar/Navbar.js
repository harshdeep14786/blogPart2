import React, { useState } from 'react';
import { HiOutlineMenuAlt4 } from 'react-icons/hi';
import { FaRegTimesCircle } from 'react-icons/fa';
import { BsFillHouseFill } from 'react-icons/bs';
import './Navbar.css';

const Navbar = ({ brand, menuItems, buttonText }) => {
    const [click, setClick] = useState(false);
    const handleClick = () => setClick(!click);

    return (
        <div className='navbar'>
            <div className='container'>
                <h1>
                    <span><BsFillHouseFill /> {brand}</span>
                </h1>

                <ul className={click ? 'nav-menu active' : 'nav-menu'}>
                    {menuItems.map((item, index) => (
                        <li key={index}><a href={item.href}>{item.text}</a></li>
                    ))}
                </ul>
                <button className='btn'>{buttonText}</button>
                <div className='hamburger' onClick={handleClick}>
                    {click ? (<FaRegTimesCircle className='icon' />) : (<HiOutlineMenuAlt4 className='icon' />)}
                </div>
            </div>
        </div>
    );
}

const App = () => {
    const brand = "AMAZON";
    const menuItems = [
        { text: "Home", href: "#" },
        { text: "Search", href: "#" },
        { text: "About", href: "#" },
        { text: "Contact", href: "#" }
    ];
    const buttonText = "Sign In";

    return (
        <Navbar 
            brand={brand}
            menuItems={menuItems}
            buttonText={buttonText}
        />
    );
}

export default App;
