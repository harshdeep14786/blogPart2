import React, { useState, useEffect } from 'react';

import Fashion from '../../assets/Fashion.jpg';
import Beauty from '../../assets/Beauty.jpg';
import Art from '../../assets/art.jpeg';
import Acc from '../../assets/4571410.jpg';
import Elect from '../../assets/OIP.jpeg';

import './Best.css';

const Best = ({ categories, images }) => {
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [filteredImages, setFilteredImages] = useState(images);

    useEffect(() => {
        // Filter images based on the selected category
        if (selectedCategory === 'All') {
            setFilteredImages(images);
        } else {
            setFilteredImages(images.filter(image => image.category === selectedCategory));
        }
    }, [selectedCategory, images]);

    return (
        <div className='best'>
            <h1>Find millions of products with fast local delivery.</h1>
            <div>
                {categories.map(category => (
                    <p key={category} onClick={() => setSelectedCategory(category)}>
                        <span className={selectedCategory === category ? 'bold' : ''}>{category}</span>
                    </p>
                ))}
            </div>
            <div className='container'>
                {filteredImages.map((image, index) => (
                    <img key={index} src={image.src} alt={image.alt} />
                ))}
            </div>
            <button className='btn'>View All</button>
        </div>
    );
}

const categories = ['All', 'Accessories', 'Beauty & Personal Care', 'Electronics', 'Art & Craft', 'Clothes'];

const images = [
    { src: Fashion, alt: 'Fashion', category: 'Clothes' },
    { src: Beauty, alt: 'Beauty', category: 'Beauty & Personal Care' },
    { src: Art, alt: 'Art', category: 'Art & Craft' },
    { src: Acc, alt: 'Accessories', category: 'Accessories' },
    { src: Elect, alt: 'Electronics', category: 'Electronics' }
];

const App = () => {
    return <Best categories={categories} images={images} />;
}

export default App;
