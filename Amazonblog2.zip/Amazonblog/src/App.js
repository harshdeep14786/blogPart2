import React from 'react';
import Featured from './components/featured/Featured';
import Best from './components/best/Best';
import Hero from './components/hero/Hero';
import Navbar from './components/navbar/Navbar';
import Footer from './components/footer/Footer';

import Maclipstick from './assets/maclipstick.jpg';
import Mac2 from './assets/mac2.jpg';
import Mac3 from './assets/mac3.jpg';
import Mac4 from './assets/mac4.jpg';
import Mac5 from './assets/mac5.jpg';

import Fashion from './assets/Fashion.jpg';
import Beauty from './assets/Beauty.jpg';
import Art from './assets/art.jpeg';
import Acc from './assets/4571410.jpg';
import Elect from './assets/OIP.jpeg';

import { FaFacebook, FaInstagram, FaTwitter, FaPinterest } from 'react-icons/fa';

function App() {
  const navbarData = {
    brand: "AMAZON",
    menuItems: [
      { text: "Home", href: "#" },
      { text: "Search", href: "#" },
      { text: "About", href: "#" },
      { text: "Contact", href: "#" }
    ],
    buttonText: "Sign In"
  };

  const heroData = {
    heading: "What are you looking for",
    searchText: "Search for the things you want.",
    placeholder: "Enter Keyword.."
  };

  const bestData = {
    categories: ['All', 'Accessories', 'Beauty & Personal Care', 'Electronics', 'Art & Craft', 'Clothes'],
    images: [
      { src: Fashion, alt: 'Fashion', category: 'Clothes' },
      { src: Beauty, alt: 'Beauty', category: 'Beauty & Personal Care' },
      { src: Art, alt: 'Art', category: 'Art & Craft' },
      { src: Acc, alt: 'Accessories', category: 'Accessories' },
      { src: Elect, alt: 'Electronics', category: 'Electronics' }
    ]
  };

  const featuredProduct = {
    name: "Maybelline New York Super Stay Matte Ink Spiced Edition, Exhilarator, 5 ml.",
    sale: "Summer Sale",
    price: "$9.98 $199.60 per ml",
    images: [Maclipstick, Mac2, Mac3, Mac4, Mac5],
    details: [
      { label: "Brand", value: "MAYBELLINE" },
      { label: "Colour", value: "Exhilarator" },
      { label: "Item Form", value: "Liquid" },
      { label: "Finish Type", value: "Matte" }
    ],
    description: "Unique arrow applicator for a more precise liquid lipstick application"
  };

  const footerData = {
    socialLinks: [
      { icon: <FaFacebook />, url: 'https://www.facebook.com' },
      { icon: <FaInstagram />, url: 'https://www.instagram.com' },
      { icon: <FaTwitter />, url: 'https://www.twitter.com' },
      { icon: <FaPinterest />, url: 'https://www.pinterest.com' },
    ],
    footerColumns: [
      { title: 'Amazon Music', description: 'Streams millions of Music' },
      { title: 'Amazon Business', description: 'Everything for your business' },
      { title: 'Amazon Drive', description: 'Cloud storage from Amazon' },
      { title: 'Amazon Web Services', description: 'Scalable Cloud Computing Services' },
    ]
  };

  return (
    <>
      <Navbar 
        brand={navbarData.brand}
        menuItems={navbarData.menuItems}
        buttonText={navbarData.buttonText}
      />
      <Hero 
        heading={heroData.heading}
        searchText={heroData.searchText}
        placeholder={heroData.placeholder}
      />
      <Best 
        categories={bestData.categories}
        images={bestData.images}
      />
      <Featured 
        product={featuredProduct}
      />
      <Footer 
        socialLinks={footerData.socialLinks}
        footerColumns={footerData.footerColumns}
      />
    </>
  );
}

export default App;
